SKIPUNZIP=0

ui_print "*******************************"
ui_print "    多模块一键批量安装器        "
ui_print "*******************************"

# 定义临时工作目录
TMP_DIR="/data/local/tmp/multi_extract"
rm -rf "$TMP_DIR"
mkdir -p "$TMP_DIR"

ui_print "- 正在提取子模块..."
unzip -o "$ZIPFILE" "fill/*.zip" -d "$TMP_DIR"

# 遍历所有子压缩包
for zipfile in "$TMP_DIR/fill"/*.zip; do
    [ -f "$zipfile" ] || continue
    
    MOD_NAME=$(basename "$zipfile")
    ui_print "- 正在处理: $MOD_NAME"
    
    # 建立单模块解压目录
    SUB_EXTRACT="$TMP_DIR/sub_out"
    rm -rf "$SUB_EXTRACT"
    mkdir -p "$SUB_EXTRACT"
    
    # 解压子模块
    unzip -q "$zipfile" -d "$SUB_EXTRACT"
    
    # 检测并读取 module.prop 中的 id
    if [ -f "$SUB_EXTRACT/module.prop" ]; then
        MOD_ID=$(grep_prop id "$SUB_EXTRACT/module.prop")
        
        if [ -n "$MOD_ID" ]; then
            ui_print "  -> 解析成功，ID: $MOD_ID"
            
            # 投递到系统的模块更新目录（Magisk 和 KernelSU 通用安全做法）
            TARGET_DIR="/data/adb/modules_update/$MOD_ID"
            rm -rf "$TARGET_DIR"
            mkdir -p "$TARGET_DIR"
            
            # 复制文件
            cp -af "$SUB_EXTRACT"/* "$TARGET_DIR"/
            
            ui_print "  [✓] 已加入重启安装队列"
        else
            ui_print "  [!] 错误: 无法在 module.prop 中找到 id"
        fi
    else
        ui_print "  [!] 错误: 压缩包内未找到 module.prop，可能不是标准模块"
    fi
done

# 清理垃圾
rm -rf "$TMP_DIR"

ui_print "-------------------------------"
ui_print "- 批量投递完成！"
ui_print "- 请直接重启手机。"
ui_print "-------------------------------"
